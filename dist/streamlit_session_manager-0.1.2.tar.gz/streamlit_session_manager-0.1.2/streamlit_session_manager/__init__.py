from .session_manager import SessionManager

__version__ = "0.1.0"  # Add your current version number